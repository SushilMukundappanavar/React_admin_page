import React, { Component } from 'react';
import logo from '../assets/img/logo.png';
import '../App.css';

class Footer extends Component {
  render() {
    return (
        <footer>Copyright Autodesk, Inc. 2018</footer>
    );
  }
}

export default Footer;
