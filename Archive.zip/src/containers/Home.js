import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom'
import logo from '../assets/img/logo.png';
import '../App.css';
import Header from '../components/Header';
import Footer from '../components/Footer';
import Alerts from '../components/Alert';
import Other1 from '../components/Other1';
import Other2 from '../components/Other2';

class Home extends Component {
  render() {
    return (
      <div className="main-wrapper container-fluid">
        <Header />
        <div class="mid-container">
          {this.props.children}
        </div>
        <Footer />
      </div>
    );
  }
}

export default Home;
