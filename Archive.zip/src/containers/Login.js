import React, { Component } from 'react';
import { Link } from 'react-router-dom'
import logo from '../assets/img/logo.png';
// import './App.css';

class Login extends Component {
  render() {
    return (
      <div className="main-wrapper">
        <div className="login-wrap container-fluid">
          <div className="container">
            <div className="row">
              <div className="login-section">
                <div className="login-logo-head">
                  <img src={logo} className="logo" alt="logo" />
                </div>
                <div className="login-mid-container">
                  <form className="login-form">
                    <div className="form-group">
                      <input type="email" className="form-control" placeholder="Email" />
                    </div>
                    <div className="form-group">
                      <input type="password" className="form-control" placeholder="password" />
                    </div>
                    <div className="form-group">
                      <button type="button" className="btn btn-primary btn-block">
                        <Link to={'/Home'}>LOGIN</Link>
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Login;