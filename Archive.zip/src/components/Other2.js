import React, { Component } from 'react';
// import '../App.css';

class Other2 extends Component {
  render() {
    return (
        <div>
            This is Other 2 Page
        </div>
    );
  }
}

export default Other2;
