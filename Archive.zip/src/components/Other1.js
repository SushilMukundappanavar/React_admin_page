import React, { Component } from 'react';
// import '../App.css';

class Other1 extends Component {
  render() {
    return (
        <div>
            This is Other 1 Page
        </div>
    );
  }
}

export default Other1;
