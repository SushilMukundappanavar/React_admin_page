import React, { Component } from 'react';
import { Link } from "react-router-dom";
import logo from '../assets/img/logo.png';
import '../App.css';
import Alerts from './Alert';
import Other1 from './Other1';
import Other2 from './Other2';

class Header extends Component {
  render() {
    return (
        <header>
          <div className="clearfix">
            <div className="col-sm-3 col-md-3">
              <a href="#"><img src={logo} className="logo" alt="logo" /></a>
            </div>
            <div className="col-sm-5 col-md-5">
              <nav>
                <ul className="clearfix">
                  <li className="active"><Link to="/Home/Alerts">Alerts</Link></li>
                  <li><Link to="/Home/Other1">Navigation-1</Link></li>
                  <li><Link to="/Home/Other2">Navigation-2</Link></li>
                </ul>
              </nav>
            </div>
            <div className="col-sm-4 col-md-4 clearfix">
              <div className="welcome-dropdown clearfix">
                <a href="#">
                  <span className="userimg"><i className="fas fa-user-circle"></i></span>
                  Florence Charlton <i class="fas fa-caret-down arrow-drop"></i>
                </a>
                <ul className="user-dropdown">
                  <li><a href="#">My Profile</a></li>
                  <li><a href="#">Setting</a></li>
                  <li><a href="#">Logout</a></li>
                </ul>
              </div>
              <div className="icon-notifi"><a href="#"><i className="far fa-bell icon"></i></a>
                <span className="red-circle">8</span>
              </div>
              <div className="icon-notifi"><a href="#"><i className="far fa-envelope icon"></i></a></div>
            </div>
          </div>
        </header>
    );
  }
}

export default Header;
