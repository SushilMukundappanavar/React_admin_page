import React, { Component } from 'react';
// import { Router, Route, browserHistory } from 'react-router';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom'
import './App.css';
import Login from './containers/Login';
import Home from './containers/Home';
import Alerts from './components/Alert';
import Other1 from './components/Other1';
import Other2 from './components/Other2';
class App extends Component {
  render() {
    return (
      <div>
        <Router>
            <Switch>
              <Route exact path='/' component={Login} />
              <Route exact path='/Home' component={Home}/>
              <Route exact path='/Home/Alerts' component={Alerts} />
                <Route exact path='/Home/Other1' component={Other1} />
                <Route exact path='/Home/Other2' component={Other2} />
            </Switch>
        </Router>
      </div>
    );
  }
}

export default App;
