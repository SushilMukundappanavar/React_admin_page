import React, { Component } from 'react';

class Alerts extends Component {
  render() {
    return (
        <div class="clearfix">
            <div className="submenus">
            <ul>
              <li className="active"><a href="#"><i class="fas fa-history icons"></i>Alerts History</a></li>
              <li><a href="#"><i class="far fa-plus-square icons"></i>Create New Alert</a></li>
              <li><a href="#"><i class="far fa-edit icons"></i>Edit Alert</a></li>
            </ul>
          </div>
          <div className="mid-right">
            <div className="row">
              <div className="col-sm-3 col-md-3 search">
                <input type="text" className="search-input" placeholder="search" />
                <i class="fas fa-search search-icon"></i>
              </div>
            </div>
            <div>
              <table class="table table-striped table-responsive">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Date Timestamp</th>
                    <th>Receipents</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>James Florence</td>
                    <td>40</td>
                    <td>Lorem Ipsum - All the facts</td>
                  </tr>
                  <tr>
                    <td>Jacob Thornton</td>
                    <td>55</td>
                    <td>Lorem Ipsum - All the</td>
                  </tr>
                  <tr>
                    <td>Mark Otto</td>
                    <td>35</td>
                    <td>Lorem Ipsum - All the facts</td>
                  </tr>
                  <tr>
                    <td>Larry Bird</td>
                    <td>28</td>
                    <td>Lorem Ipsum - All the facts</td>
                  </tr>
                  <tr>
                    <td>James Florence</td>
                    <td>40</td>
                    <td>Lorem Ipsum - All the facts</td>
                  </tr>
                  <tr>
                    <td>Jacob Thornton</td>
                    <td>55</td>
                    <td>Lorem Ipsum - All the</td>
                  </tr>
                  <tr>
                    <td>Mark Otto</td>
                    <td>35</td>
                    <td>Lorem Ipsum - All the facts</td>
                  </tr>
                  <tr>
                    <td>Larry Bird</td>
                    <td>28</td>
                    <td>Lorem Ipsum - All the facts</td>
                  </tr>
                  <tr>
                    <td>James Florence</td>
                    <td>40</td>
                    <td>Lorem Ipsum - All the facts</td>
                  </tr>
                  <tr>
                    <td>Jacob Thornton</td>
                    <td>55</td>
                    <td>Lorem Ipsum - All the</td>
                  </tr>
                  <tr>
                    <td>Mark Otto</td>
                    <td>35</td>
                    <td>Lorem Ipsum - All the facts</td>
                  </tr>
                  <tr>
                    <td>Larry Bird</td>
                    <td>28</td>
                    <td>Lorem Ipsum - All the facts</td>
                  </tr>
                  <tr>
                    <td>James Florence</td>
                    <td>40</td>
                    <td>Lorem Ipsum - All the facts</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
    );
  }
}

export default Alerts;
